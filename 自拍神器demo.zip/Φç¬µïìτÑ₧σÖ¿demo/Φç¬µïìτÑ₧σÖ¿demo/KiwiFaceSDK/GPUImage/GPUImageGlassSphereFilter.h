#import "GPUImageSphereRefractionFilter.h"

@interface GPUImageGlassSphereFilter : GPUImageSphereRefractionFilter

@end
