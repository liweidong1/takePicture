#import "GPUImageTwoInputFilter.h"

@interface GPUImageSourceOverBlendFilter : GPUImageTwoInputFilter

@end
